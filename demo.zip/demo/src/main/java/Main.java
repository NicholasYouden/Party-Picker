import javax.swing.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Friend> friends = new ArrayList<>();
        JOptionPane.showMessageDialog(null, "Welcome to the party guest list program!");
        boolean isAddingGuests = true;
        while (isAddingGuests) {
            String firstName = JOptionPane.showInputDialog("Enter the first name of the guest (or cancel to stop adding guests):");
            if (firstName == null) {
                isAddingGuests = false;
            } else {
                String lastName = JOptionPane.showInputDialog("Enter the last name of the guest:");
                boolean isInvited = JOptionPane.showConfirmDialog(null, "Is the guest invited to the party?", "Invitation status", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
                String foodToBring = JOptionPane.showInputDialog("Enter the food the guest usually brings:");
                Friend friend = new Friend(firstName, lastName, isInvited, foodToBring);
                friends.add(friend);
            }
        }
        StringBuilder report = new StringBuilder("Party guest list:\n");
        for (Friend friend : friends) {
            report.append(friend.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }
}